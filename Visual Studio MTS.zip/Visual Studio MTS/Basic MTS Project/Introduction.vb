﻿Public Class GlobalVariables
    Public Shared CompOne As Integer
    Public Shared CompTwo As Integer
    Public Shared CompThree As Integer
    Public Shared CorrectResponse As Integer
    Public Shared randomnumber As Integer
    Public Shared count As Integer
    Public Shared randomtwo As Integer
    Public Shared SampleTime As New Stopwatch()
    Public Shared ComparisonTime As New Stopwatch()
    Public Shared et As TimeSpan
    Public Shared timestring As String
    Public Shared SampleImage
End Class

Public Class Introduction
    Public count As Integer = 0
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Public Sub ChooseSampleImage()
        ' Initialize the random-number generator.
        Randomize()
        ' Generate random value between 1 and 6. 
        GlobalVariables.randomnumber = CInt(Int((6 * Rnd()) + 1))

        'Choose Image
        Select Case GlobalVariables.randomnumber
            Case 1
                Sample.PictureBox1.Image = Global.Basic_MTS_Project.My.Resources.Resources.A1
            Case 2
                Sample.PictureBox1.Image = Global.Basic_MTS_Project.My.Resources.Resources.A2
            Case 3
                Sample.PictureBox1.Image = Global.Basic_MTS_Project.My.Resources.Resources.A3
            Case 4
                Sample.PictureBox1.Image = Global.Basic_MTS_Project.My.Resources.Resources.A4
            Case 5
                Sample.PictureBox1.Image = Global.Basic_MTS_Project.My.Resources.Resources.A5
            Case 6
                Sample.PictureBox1.Image = Global.Basic_MTS_Project.My.Resources.Resources.A6
        End Select
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        GlobalVariables.count = 0

        My.Computer.FileSystem.WriteAllText("C://ParticipantData/participantdata.txt", "Sample Image, Sample Timer, Comparison Response, Comparison Timer, Correct Response " + vbCrLf, True)

        Me.ChooseSampleImage()

        GlobalVariables.SampleTime.Start()
        Sample.Show()
        Me.Hide()
    End Sub
End Class